﻿<#
   PALISADE JAVA DATA COLLECTION SCRIPT FOR WINDOWS POWERSHELL
   USAGE: collect_java.cmd

   TERMS FOR PALISADE COMPLIANCE DATA COLLECTION TOOL ("TOOL")
   This Agreement supplements the Master Agreement in place between your company/organization and Palisade Compliance.  If no Master Agreement is in place, the terms of this agreement govern your use of the Palisade Tool.   By your use of the Tool, you indicate your acceptance of these terms and your agreement, as an authorized representative of your company or organization (if being acquired for use by an entity) or as an individual, to comply with the following license terms that apply to the Tool.  If you are not willing to be bound by these terms, do not indicate your acceptance and do not download, install, or use the Tool.

   This data collection Tool is not Software or a Deliverable within the meaning of any contract that may be in place between Your organization and Palisade.  This Tool is not commercially available, and is a part of the data intake process for use of Palisade services.
   License Agreement

   PLEASE SCROLL DOWN AND READ ALL OF THE FOLLOWING TERMS AND CONDITIONS OF THIS LICENSE AGREEMENT ("Agreement") CAREFULLY.  THIS AGREEMENT IS A LEGALLY BINDING CONTRACT BETWEEN YOU AND PALISADE COMPLIANCE, LLC THAT SETS FORTH THE TERMS AND CONDITIONS THAT GOVERN YOUR USE OF THE TOOL.

   YOU MUST ACCEPT AND ABIDE BY THESE TERMS AND CONDITIONS AS PRESENTED TO YOU - ANY CHANGES, ADDITIONS OR DELETIONS BY YOU TO THESE TERMS AND CONDITIONS WILL NOT BE ACCEPTED BY US AND WILL NOT BE PART OF THIS AGREEMENT.

   Definitions
   "We," "Us," and "Our" refers to Palisade Compliance, LLC.  "Palisade" refers to Palisade Compliance, LLC, Palisade Compliance LTD and their affiliates.

   "You" and "Your" refers to the individual or entity that wishes to use the Tool (as defined below) provided by Palisade.

   "Tool" refers to the tool(s), script(s) and/or product(s) and any applicable documentation provided to You by Palisade which You wish to access and use to measure Your usage of separately-licensed third-party software.

   Rights Granted
   We grant You a non-exclusive, non-transferable limited right to use the Tool, subject to the terms of this Agreement, for the limited purpose of measuring Your usage of separately-licensed third-party software as a current client of Palisade.  During the term of your Agreement with Palisade, You may allow Your agents and contractors (including, without limitation, outsourcers) to use the Tool for this purpose and You are responsible for their compliance with this Agreement in such use.  You (including Your agents, contractors and/or outsourcers) may not use the Tool for any other purpose or beyond the end date of your Agreement with Palisade.

   Ownership and Restrictions
   Palisade retains all ownership and intellectual property rights to the Tool. The Tool may be installed on one or more servers; provided, however, that You may only make one copy of the Tool for backup or archival purposes.

   You may not:
   -  use the Tool for Your own internal data processing or for any commercial or production purposes, or use the Tool for any purpose except the purpose stated herein;
   -  remove or modify any Tool markings or any notice of Palisade's proprietary rights;
   -  make the Tool available in any manner to any third party for use in the third party's business operations, without Our prior written consent;
   -  use the Tool to provide third party training or rent or lease the Tool or use the Tool for commercial time sharing or service bureau use;
   -  assign this Agreement or give or transfer the Tool or an interest in them to another individual or entity;
   -  cause or permit reverse engineering (unless required by law for interoperability), disassembly or decompilation of the Tool (the foregoing prohibition includes but is not limited to review of data structures or similar materials produced by Tool);
   -  use any Palisade name, trademark or logo without Our prior written consent .

   Disclaimer of Warranty
   PALISADE DOES NOT GUARANTEE THAT THE TOOL WILL PERFORM ERROR-FREE OR UNINTERRUPTED.   TO THE EXTENT NOT PROHIBITED BY LAW, THE TOOL ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND AND THERE ARE NO WARRANTIES, EXPRESS OR IMPLIED, OR CONDITIONS, INCLUDING WITHOUT LIMITATION, WARRANTIES OR CONDITIONS OF MERCHANTABILITY, NONINFRINGEMENT OR FITNESS FOR A PARTICULAR PURPOSE, THAT APPLY TO THE TOOL.

   No Right to Technical Support
   You acknowledge and agree that Palisade's technical support organization will not provide You with technical support for the Tool licensed under this Agreement.

   End of Agreement
   You may terminate this Agreement by destroying all copies of the Tool. We have the right to terminate Your right to use the Tool at any time upon notice to You, in which case You shall destroy all copies of the Tool.

   Entire Agreement
   You agree that this Agreement is the complete agreement for the Tool and supersedes all prior or contemporaneous agreements or representations, written or oral, regarding such Tool. If any term of this Agreement is found to be invalid or unenforceable, the remaining provisions will remain effective and such term shall be replaced with a term consistent with the purpose and intent of this Agreement.

   Limitation of Liability
   IN NO EVENT SHALL PALISADE BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, PUNITIVE OR CONSEQUENTIAL DAMAGES, OR ANY LOSS OF PROFITS, REVENUE, DATA OR DATA USE, INCURRED BY YOU OR ANY THIRD PARTY.  PALISADE'S ENTIRE LIABILITY FOR DAMAGES ARISING OUT OF OR RELATED TO THIS AGREEMENT, WHETHER IN CONTRACT OR TORT OR OTHERWISE, SHALL IN NO EVENT EXCEED ONE THOUSAND U.S. DOLLARS (U.S. $1,000).

   Export
   Export laws and regulations of the United States and any other relevant local export laws and regulations may apply to the Tool.  You agree that such export control laws govern Your use of the Tool (including technical data) provided under this Agreement, and You agree to comply with all such export laws and regulations (including "deemed export" and "deemed re-export" regulations).  You agree that no data, information, and/or Tool (or direct product thereof) will be exported, directly or indirectly, in violation of any export laws, nor will they be used for any purpose prohibited by these laws including, without limitation, nuclear, chemical, or biological weapons proliferation, or development of missile technology.

   Other
   1. This Agreement is governed by the substantive and procedural laws of the State of New Jersey, USA. You and We agree to submit to the exclusive jurisdiction of, and venue in, the courts of Morris County, New Jersey in any dispute arising out of or relating to this Agreement.

   2. You may not assign this Agreement or give or transfer the Tool or an interest in them to another individual or entity.  If You grant a security interest in the Tool, the secured party has no right to use or transfer the Tool.

   3. Except for actions for breach of Palisade's proprietary rights, no action, regardless of form, arising out of or relating to this Agreement may be brought by either party more than two years after the cause of action has accrued.

   4. The relationship between You and Us is that of licensee/licensor. Nothing in this Agreement shall be construed to create a partnership, joint venture, agency, or employment relationship between the parties.  The parties agree that they are acting solely as independent contractors hereunder and agree that the parties have no fiduciary duty to one another or any other special or implied duties that are not expressly stated herein.  Neither party has any authority to act as agent for, or to incur any obligations on behalf of or in the name of the other.

   5. This Agreement may not be modified and the rights and restrictions may not be altered or waived except in a writing signed by authorized representatives of You and of Us.

   6. Any notice required under this Agreement shall be provided to the other party in writing.

   7. Palisade Compliance highly recommends that customers execute the collect_java.ps1 script on one or more "non-production" environment(s) before executing on any "production" environments.
#>



#Functions

function testElevated
{
    $currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function getDateTime {
    $global:currentDateTime = Get-Date -Format "yyyyMMddHHmm"
}

function writeToFile ($stringToWrite, $outputFile, $isAppend) {
    If ( $isAppend -eq 1 ) {
        Write $stringToWrite | Out-File -FilePath $outputFile -Encoding utf8 -Append
    } else {
        Write $stringToWrite | Out-File -FilePath $outputFile -Encoding utf8
    }
}

function deleteExistingFile ($fileToDelete) {
    If (Test-Path $fileToDelete) {
        Remove-Item -Path $fileToDelete
    }
}

function evalError {
    If(-Not $?) {
        $global:unhandledErrorMessage = $Error[0].Exception.Message
        $withError = $true
    } else {
        $withError= $false
        $global:unhandledErrorMessage = ""
    }
}

function evalErrorDetails {
    if ([string]::IsNullOrWhiteSpace($global:unhandledErrorMessage)) {
        Get-Content $errTmpFile | ForEach-Object {
            if(-Not ($_ -like "*CategoryInfo*" -or $_ -like "*At line*" -or $_ -like "*FullyQualifiedError*") -and ($_ -like "*PermissionDenied*" -or $_ -like "*ObjectNotFound*" -or $_ -like "*denied*")) {
                $global:errorMessage=$_.Trim()
                writeToFile $outputPrefix"script command error,"$global:errorMessage $outputFile 1
                $global:errorMessage=""
            }
        }
    } else {
        $global:errorMessage=$global:unhandledErrorMessage
        writeToFile $outputPrefix"script command error,"$global:errorMessage $outputFile 1
        $global:unhandledErrorMessage=""
    }
    $global:errorMessage=""
    deleteExistingFile $errTmpFile
}

function executePsCommand ($commandToExecute,$withLogging) {
    if ($withLogging) {
        writeToFile $outputPrefix"script command,"$commandToExecute $outputFile 1
    }
    invoke-expression $commandToExecute 2>>$errTmpFile
}

function searchJavaInstallations {
    [bool] $thisIsExcluded = $false
    $searchDrv.Split(" ") | ForEach {
        Get-Acl $_ >$null 2>&1
        if ($?) {
            $thisDrv=$_
            cd $thisDrv\\
            $searchDirs=@((Get-ChildItem -Directory -Force).Name).Replace(" ",":")
            $searchDirs.Split(" ") | ForEach {
                $thisDir=$_.Replace(":"," ")
                $thisIsExcluded = $false
                $global:palExcludedDirs.Replace(" ",":").Split(" ") | ForEach {
                    if ( "$_".Replace(":"," ") -eq "$thisDir") {
                        $thisIsExcluded = $true
                    }
                }
                if ($thisIsExcluded) {
                    if (-Not $withSilent) {
                        getDateTime
                        Write-Output "${global:palCurrentDateTime} - Skip $thisDir on drive $thisDrv"
                    }
                } else {
                    if (-Not $withSilent) {
                        getDateTime
                        Write-Output "${global:palCurrentDateTime} - Search $thisDir on drive $thisDrv"
                    }
                    $command = "robocopy `"$thisDrv\$thisDir`" `"$scriptPath`" java.exe /L /S /NJH /NJS /FP /NC /NDL /R:0 /W:0 /XJ /NS >> `"$dlistTmpFile`""
                    executePsCommand $command $true
                    evalError
                    evalErrorDetails
                    start-sleep -Seconds 3
                }
            }
        }
    }
}

function scanJavaInfo {
    Get-Content $dlistTmpFile | ForEach-Object {
        $currentLine = $_.Trim()
        if(($currentLine -like "*:\*java*") -and ($currentLine -notlike "*\javapath_target_*") -and ($currentLine -notlike "*\VFS\SystemX86*")) {
            $currentJavaFolder = $(Split-Path -Path $currentLine)
            $currentJavaTest = $currentJavaFolder+"\java.exe"
            if (Test-Path $currentJavaTest)
            {
                writeToFile $outputPrefix"java jdk/jre detected folder,"$currentJavaFolder $outputFile 1
                if (-Not$withSilent)
                {
                    Write-Output "Check Java version on"$currentJavaFolder
                }
                $currentJavaTest = $currentJavaFolder + "\java.exe"
                deleteExistingFile $jverTmpFile
                $jverTmpFileNoOfLines = 0
                $proc = Start-Process $currentJavaTest -ArgumentList "-version" -NoNewWindow -Wait -Passthru -RedirectStandardError $jverTmpFile
                if ($proc)
                {
                    do
                    {
                        start-sleep -Milliseconds 500
                    }
                    until ($proc.HasExited)
                }
                $jverTmpFileNoOfLines = (Get-Content $jverTmpFile | Measure-Object -Line).Lines
                if ($jverTmpFileNoOfLines -gt 0)
                {
                    $currentJavaVersion = ""
                }
                else
                {
                    $currentJavaVersion = "version cannot be retrieved"
                }
                $currentLineNo=1
                Get-Content $jverTmpFile | ForEach-Object {
                    if ($_)
                    {
                        if ($currentLineNo -eq 1)
                        {
                            $currentJavaVersion = ($_.Replace("`r`n", "")).Trim()
                        }
                        else
                        {
                            $currentJavaVersion = $currentJavaVersion + " " + ($_.Replace("`r`n", "")).Trim()
                        }
                        $currentLineNo++
                    }
                }
                writeToFile $outputPrefix"java version,"$currentJavaVersion $outputFile 1
                getDateForFolder $currentJavaTest $false
            }
        }
    }
}

function checkDriveAccess {
    $searchDrv.Split(" ") | ForEach {
        $command = "Get-Acl $_ >>`$null"
        executePsCommand $command $true
        evalError
        evalErrorDetails
    }
}

function scanJavaInfoForProcessLauncher ($launcherPath) {
    if(($launcherPath -like "*:\*") -or ($launcherPath -like "*\\*")) {
        $currentJavaTest = $launcherPath.Trim()+"\java.exe"
        if (Test-Path $currentJavaTest)
        {
            if (-Not $withSilent) {
                Write-Output "Check Java version on"$launcherPath
            }
            deleteExistingFile $jverTmpFile
            $jverTmpFileNoOfLines = 0
            $proc = Start-Process $currentJavaTest -ArgumentList "-version" -NoNewWindow -Wait -Passthru -RedirectStandardError $jverTmpFile
            if ($proc)
            {
                do
                {
                    start-sleep -Milliseconds 500
                }
                until ($proc.HasExited)
            }
            $jverTmpFileNoOfLines = (Get-Content $jverTmpFile | Measure-Object -Line).Lines
            if ($jverTmpFileNoOfLines -gt 0)
            {
                $currentJavaVersion = ""
            }
            else
            {
                $currentJavaVersion = "version cannot be retrieved"
            }
            $currentLineNo=1
            Get-Content $jverTmpFile | ForEach-Object {
                if ($_)
                {
                    if ($currentLineNo -eq 1)
                    {
                        $currentJavaVersion = ($_.Replace("`r`n", "")).Trim()
                    }
                    else
                    {
                        $currentJavaVersion = $currentJavaVersion + " " + ($_.Replace("`r`n", "")).Trim()
                    }
                    $currentLineNo++
                }
            }
            writeToFile $outputPrefix"java jdk/jre detected folder per process command,"$launcherPath $outputFile 1
            writeToFile $outputPrefix"java version per process command,"$currentJavaVersion $outputFile 1
            getDateForFolder $currentJavaTest $true
        }
    }
}

function getDateForFolder ($testedPath,$isProcess) {
    $creationDate = (Get-ChildItem -Path $testedPath | Select CreationTime).CreationTime.tostring("yyyy-MM-dd")
    $modifyDate = (Get-ChildItem -Path $testedPath | Select LastWriteTime).LastWriteTime.tostring("yyyy-MM-dd")
    if ($isProcess) {
        $javaDateString = "java date per process command,"
    } else {
        $javaDateString = "java date,"
    }
    $displayTestedPath=$testedPath.Replace("\java.exe","")
    writeToFile $outputPrefix$javaDateString$modifyDate"<MDATE>"$creationDate"<CDATE> "$displayTestedPath $outputFile 1
}

function getJavaProcesses {
    $javaProcesses = (Get-CimInstance -Query "SELECT * from Win32_Process WHERE name LIKE 'java%.exe'").ProcessId
    if ($javaProcesses.Length -gt 0) {
        for ($i=0; $i -le $javaProcesses.Length; $i++) {
            if ($javaProcesses[$i]) {
                $thisJavaProcessPid = $javaProcesses[$i]
                $thisJavaProcessCommand = (Get-CimInstance Win32_Process -Filter "ProcessId=$thisJavaProcessPid").CommandLine
                $thisJavaProcessCommandLauncher = (Get-CimInstance Win32_Process -Filter "ProcessId=$thisJavaProcessPid").ExecutablePath
                if ($thisJavaProcessCommandLauncher)
                {
                    $thisJavaLauncherPath = $thisJavaProcessCommandLauncher.Substring(0,$thisJavaProcessCommandLauncher.LastIndexOf("`\"))
                    writeToFile $outputPrefix"java process info,"$thisJavaProcessPid" "$thisJavaProcessCommand $outputFile 1
                    writeToFile $outputPrefix"java command,"$thisJavaProcessCommandLauncher $outputFile 1
                    scanJavaInfoForProcessLauncher $thisJavaLauncherPath
                } else {
                    writeToFile $outputPrefix"java process error,unable to retrieve info for java process "$thisJavaProcessPid $outputFile 1
                }
            }
        }
    }
    else {
        writeToFile $outputPrefix"script info,no java processes detected" $outputFile 1
    }
}

function detectAllDrv {
    $detectedDrives = @((Get-WmiObject -Class Win32_logicaldisk | Select-Object DeviceID).DeviceID)
    for ( $i = 0; $i -lt $detectedDrives.Count; $i++ ) {
        $currentDrive = ""
        $currentDriveType = ""
        $currentDriveProvided = ""
        $currentDrive = $detectedDrives[$i]
        $currentDriveType = @((Get-WmiObject -Class Win32_logicaldisk -Filter "DeviceID = '$currentDrive'" | Select-Object DriveType).DriveType)
        if (($currentDriveType -eq 4) -and (-Not $withRestricted)) {
            $currentDriveProvider = @((Get-WmiObject -Class Win32_logicaldisk -Filter "DeviceID = '$currentDrive'" | Select-Object ProviderName).ProviderName)
        }
        $currentDrive = $currentDrive.trim()
        writeToFile $outputPrefix"detected drive,"$currentDrive","$currentDriveType","$currentDriveProvider $outputFile 1
    }
}

function checkPreq {
    if ( $PSVersionTable.PSVersion.Major -gt 2 ) {
        $global:validPsVer = $true
    }
}

function calculateCores
{
    foreach ( $objProcessor in (Get-WmiObject -Query "Select Name,Description,MaxClockSpeed,NumberOfCores,NumberOfLogicalProcessors from Win32_Processor") )
    {
        $thisProcessorCores = $objProcessor.NumberOfCores
        $global:palNumberOfCores = $global:palNumberOfCores + $thisProcessorCores
    }
}

#Main

$VerbosePreference = "SilentlyContinue"
$PSDefaultParameterValues["out-file:width"]=6000
$process = Get-Process -Id $pid
$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$cmdOutputPath = ""
$outputPath = ""
$osName = (Get-WmiObject -class Win32_OperatingSystem).Caption
$osVersion = (Get-WmiObject -class Win32_OperatingSystem).Version
$custName = "palcust"
$scriptName = "paljvwps"
$scriptVersion = "2.1.1"
$scriptUname = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$machineName = [System.Net.Dns]::GetHostName()
$global:currentDateTime = Get-Date -Format "yyyyMMddHHmmss"
$global:palExcludedDirs = @("Windows","PerfLogs","`$Recycle.Bin","Boot","Recovery","System Volume Information","`$Windows.~WS","`$WINDOWS.~BT","`$WINDOWS.~LS","`$WinREAgent","Documents and Settings","ProgramData")
$outputPrefix = "***===,"+$machineName+","
$currentDrive = ""
$global:errorMessage = ""
$global:unhandledErrorMessage = ""
[bool] $withLogging = $false
[bool] $isElevated = $false
[bool] $withSilent = $false
[bool] $withNetworkFs = $false
[bool] $withRemovableFs = $false
[bool] $withRestricted = $false
[bool] $global:validPsVer = $false

checkPreq

$psFullVer = [string]($PSVersionTable.PSVersion.Major)+'.'+[string]($PSVersionTable.PSVersion.Minor)

for ( $i = 0; $i -lt $args.count; $i++ ) {
    Switch ($($args[$i]))
    {
        "-silent" {$withSilent=$true}
        "-includenetwork" {$withNetworkFs=$true}
        "-includeremovable" {$withRemovableFs=$true}
        "-restricted" {$withRestricted=$true}
        "-output" {$cmdOutputPath=$args[$i+1]}
        default {}
    }
}

$cmdOutputPath = $cmdOutputPath.Trim()

if (($cmdOutputPath) -and (Test-Path $cmdOutputPath)) {
    $outputPath = $cmdOutputPath
} else {
    $outputPath = $scriptPath
}

$outputFile = $outputPath+"\"+$custName+"-paljv-"+$machineName+"__"+$currentDateTime+"P"+$PID+".txt"
$dlistTmpFile = $outputPath+"\"+$machineName+"-"+$PID+"-detectedjava.tmp"
$jverTmpFile = $outputPath+"\"+$machineName+"-"+$PID+"-javaversion.tmp"
$errTmpFile = $outputPath+"\"+$machineName+"-"+$PID+"-errors.tmp"

calculateCores

if ($global:palNumberOfCores -lt 3) {
    $process.PriorityClass = 'Idle'
} else {
    $process.PriorityClass = 'BelowNormal'
}

if ($global:validPsVer) {
    if ((-Not $withNetworkFs) -and (-Not $withRemovableFs)) {
        $searchDrv = @((Get-WmiObject -Class Win32_logicaldisk -Filter "DriveType = '3'" | Select-Object DeviceID).DeviceID)
    }

    if (($withNetworkFs) -and ($withRemovableFs)) {
        $searchDrv = @((Get-WmiObject -Class Win32_logicaldisk -Filter "DriveType = '2' OR DriveType = '3' OR DriveType = '4'" | Select-Object DeviceID).DeviceID)
    }

    if (($withNetworkFs) -and (-Not $withRemovableFs)) {
        $searchDrv = @((Get-WmiObject -Class Win32_logicaldisk -Filter "DriveType = '3' OR DriveType = '4'" | Select-Object DeviceID).DeviceID)
    }

    if ((-Not $withNetworkFs) -and ($withRemovableFs)) {
        $searchDrv = @((Get-WmiObject -Class Win32_logicaldisk -Filter "DriveType = '2' OR DriveType = '3'" | Select-Object DeviceID).DeviceID)
    }
}

deleteExistingFile $dlistTmpFile
deleteExistingFile $jverTmpFile
deleteExistingFile $errTmpFile

$isElevated = testElevated
$priorityClass = ($process).PriorityClass

if (-Not $withSilent) {
    Write-Host "Palisade Java Collection Tool v$scriptVersion - PowerShell"
    Write-Host ""
    Write-Host "Scan"$machineName" for Java installations and processes..."
    Write-Host ""
    if (-Not $global:validPsVer) {
        Write-Host "This script cannot be executed with PowerShell v$psFullVer. Please contact Palisade Compliance for assistance."
    }
}

writeToFile $outputPrefix"script version,"$scriptName"-"$scriptVersion $outputFile 0
if ( $withRestricted ) {
    writeToFile $outputPrefix"script user,n/a" $outputFile 1
} else {
    writeToFile $outputPrefix"script user,"$scriptUname $outputFile 1
}
writeToFile $outputPrefix"is elevated,"$isElevated $outputFile 1
getDateTime
writeToFile $outputPrefix"script start time,"$global:currentDateTime $outputFile 1
writeToFile $outputPrefix"number of cores,"$global:palNumberOfCores $outputFile 1
writeToFile $outputPrefix"priority,"$priorityClass $outputFile 1
writeToFile $outputPrefix"os,"$osName $outputFile 1
writeToFile $outputPrefix"os version,"$osVersion $outputFile 1
writeToFile $outputPrefix"powershell version,"$psFullVer $outputFile 1
writeToFile $outputPrefix"command line parameters,"$args $outputFile 1
if ($global:validPsVer) {
    detectAllDrv
    writeToFile $outputPrefix"java collection in folders,"$searchDrv $outputFile 1
}

Set-Location $outputPath

if ($global:validPsVer) {
    checkDriveAccess
    searchJavaInstallations
    scanJavaInfo
}

if ((-Not $withSilent) -and ($global:validPsVer)) {
    Write-Output $javaDetectedPaths
}

if ($global:validPsVer) {
    getJavaProcesses
} else {
    writeToFile $outputPrefix"script critical error, PS version lower than 3.0" $outputFile 1
}

getDateTime

writeToFile $outputPrefix"script end time,"$global:currentDateTime $outputFile 1
writeToFile "<EOF>" $outputFile 1

deleteExistingFile $dlistTmpFile
deleteExistingFile $jverTmpFile
deleteExistingFile $errTmpFile

if (-Not $withSilent) {
    Write-Host ""
    Write-Host "====="
    Write-Host "Please collect and send "$outputFile" file to Palisade Compliance for analysis."
    Write-Host "====="

    Read-Host -Prompt "Press any key..."
}