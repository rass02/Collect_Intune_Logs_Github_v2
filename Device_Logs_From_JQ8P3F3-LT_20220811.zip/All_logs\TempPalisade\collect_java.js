/*
collect_java.js
 */

/*

   PALISADE JAVA DATA COLLECTION SCRIPT FOR WINDOWS
   USAGE: collect_java.cmd

   TERMS FOR PALISADE COMPLIANCE DATA COLLECTION TOOL ("TOOL")
   This Agreement supplements the Master Agreement in place between your company/organization and Palisade Compliance.  If no Master Agreement is in place, the terms of this agreement govern your use of the Palisade Tool.   By your use of the Tool, you indicate your acceptance of these terms and your agreement, as an authorized representative of your company or organization (if being acquired for use by an entity) or as an individual, to comply with the following license terms that apply to the Tool.  If you are not willing to be bound by these terms, do not indicate your acceptance and do not download, install, or use the Tool.

   This data collection Tool is not Software or a Deliverable within the meaning of any contract that may be in place between Your organization and Palisade.  This Tool is not commercially available, and is a part of the data intake process for use of Palisade services.
   License Agreement

   PLEASE SCROLL DOWN AND READ ALL OF THE FOLLOWING TERMS AND CONDITIONS OF THIS LICENSE AGREEMENT ("Agreement") CAREFULLY.  THIS AGREEMENT IS A LEGALLY BINDING CONTRACT BETWEEN YOU AND PALISADE COMPLIANCE, LLC THAT SETS FORTH THE TERMS AND CONDITIONS THAT GOVERN YOUR USE OF THE TOOL.

   YOU MUST ACCEPT AND ABIDE BY THESE TERMS AND CONDITIONS AS PRESENTED TO YOU - ANY CHANGES, ADDITIONS OR DELETIONS BY YOU TO THESE TERMS AND CONDITIONS WILL NOT BE ACCEPTED BY US AND WILL NOT BE PART OF THIS AGREEMENT.

   Definitions
   "We," "Us," and "Our" refers to Palisade Compliance, LLC.  "Palisade" refers to Palisade Compliance, LLC, Palisade Compliance LTD and their affiliates.

   "You" and "Your" refers to the individual or entity that wishes to use the Tool (as defined below) provided by Palisade.

   "Tool" refers to the tool(s), script(s) and/or product(s) and any applicable documentation provided to You by Palisade which You wish to access and use to measure Your usage of separately-licensed third-party software.

   Rights Granted
   We grant You a non-exclusive, non-transferable limited right to use the Tool, subject to the terms of this Agreement, for the limited purpose of measuring Your usage of separately-licensed third-party software as a current client of Palisade.  During the term of your Agreement with Palisade, You may allow Your agents and contractors (including, without limitation, outsourcers) to use the Tool for this purpose and You are responsible for their compliance with this Agreement in such use.  You (including Your agents, contractors and/or outsourcers) may not use the Tool for any other purpose or beyond the end date of your Agreement with Palisade.

   Ownership and Restrictions
   Palisade retains all ownership and intellectual property rights to the Tool. The Tool may be installed on one or more servers; provided, however, that You may only make one copy of the Tool for backup or archival purposes.

   You may not:
   -  use the Tool for Your own internal data processing or for any commercial or production purposes, or use the Tool for any purpose except the purpose stated herein;
   -  remove or modify any Tool markings or any notice of Palisade's proprietary rights;
   -  make the Tool available in any manner to any third party for use in the third party's business operations, without Our prior written consent;
   -  use the Tool to provide third party training or rent or lease the Tool or use the Tool for commercial time sharing or service bureau use;
   -  assign this Agreement or give or transfer the Tool or an interest in them to another individual or entity;
   -  cause or permit reverse engineering (unless required by law for interoperability), disassembly or decompilation of the Tool (the foregoing prohibition includes but is not limited to review of data structures or similar materials produced by Tool);
   -  use any Palisade name, trademark or logo without Our prior written consent.

   Disclaimer of Warranty
   PALISADE DOES NOT GUARANTEE THAT THE TOOL WILL PERFORM ERROR-FREE OR UNINTERRUPTED.   TO THE EXTENT NOT PROHIBITED BY LAW, THE TOOL ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND AND THERE ARE NO WARRANTIES, EXPRESS OR IMPLIED, OR CONDITIONS, INCLUDING WITHOUT LIMITATION, WARRANTIES OR CONDITIONS OF MERCHANTABILITY, NONINFRINGEMENT OR FITNESS FOR A PARTICULAR PURPOSE, THAT APPLY TO THE TOOL.

   No Right to Technical Support
   You acknowledge and agree that Palisade's technical support organization will not provide You with technical support for the Tool licensed under this Agreement.

   End of Agreement
   You may terminate this Agreement by destroying all copies of the Tool. We have the right to terminate Your right to use the Tool at any time upon notice to You, in which case You shall destroy all copies of the Tool.

   Entire Agreement
   You agree that this Agreement is the complete agreement for the Tool and supersedes all prior or contemporaneous agreements or representations, written or oral, regarding such Tool. If any term of this Agreement is found to be invalid or unenforceable, the remaining provisions will remain effective and such term shall be replaced with a term consistent with the purpose and intent of this Agreement.

   Limitation of Liability
   IN NO EVENT SHALL PALISADE BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, PUNITIVE OR CONSEQUENTIAL DAMAGES, OR ANY LOSS OF PROFITS, REVENUE, DATA OR DATA USE, INCURRED BY YOU OR ANY THIRD PARTY.  PALISADE'S ENTIRE LIABILITY FOR DAMAGES ARISING OUT OF OR RELATED TO THIS AGREEMENT, WHETHER IN CONTRACT OR TORT OR OTHERWISE, SHALL IN NO EVENT EXCEED ONE THOUSAND U.S. DOLLARS (U.S. $1,000).

   Export
   Export laws and regulations of the United States and any other relevant local export laws and regulations may apply to the Tool.  You agree that such export control laws govern Your use of the Tool (including technical data) provided under this Agreement, and You agree to comply with all such export laws and regulations (including "deemed export" and "deemed re-export" regulations).  You agree that no data, information, and/or Tool (or direct product thereof) will be exported, directly or indirectly, in violation of any export laws, nor will they be used for any purpose prohibited by these laws including, without limitation, nuclear, chemical, or biological weapons proliferation, or development of missile technology.

   Other
   1. This Agreement is governed by the substantive and procedural laws of the State of New Jersey, USA. You and We agree to submit to the exclusive jurisdiction of, and venue in, the courts of Morris County, New Jersey in any dispute arising out of or relating to this Agreement.

   2. You may not assign this Agreement or give or transfer the Tool or an interest in them to another individual or entity.  If You grant a security interest in the Tool, the secured party has no right to use or transfer the Tool.

   3. Except for actions for breach of Palisade's proprietary rights, no action, regardless of form, arising out of or relating to this Agreement may be brought by either party more than two years after the cause of action has accrued.

   4. The relationship between You and Us is that of licensee/licensor. Nothing in this Agreement shall be construed to create a partnership, joint venture, agency, or employment relationship between the parties.  The parties agree that they are acting solely as independent contractors hereunder and agree that the parties have no fiduciary duty to one another or any other special or implied duties that are not expressly stated herein.  Neither party has any authority to act as agent for, or to incur any obligations on behalf of or in the name of the other.

   5. This Agreement may not be modified and the rights and restrictions may not be altered or waived except in a writing signed by authorized representatives of You and of Us.

   6. Any notice required under this Agreement shall be provided to the other party in writing.

   7. Palisade Compliance highly recommends that customers execute the collect_java.js script on one or more "non-production" environment(s) before executing on any "production" environments.

 */

//Set up local variables
var WshShell = WScript.CreateObject("WScript.Shell");
var fso = new ActiveXObject("Scripting.FileSystemObject");
var wbemFlagReturnImmediately = 0x10;
var wbemFlagForwardOnly = 0x20;
var SCRIPT_ARGS = WScript.Arguments;
var FRead = 1;
var FWrite = 2;
var FAppend = 8;

var PPID = get_pid();
var PCHOME = fso.getFolder(".").path;
var PDATE = new Date();
var SCRIPT_NAME = "paljvwjs";
var SCRIPT_VERSION = "2.1.1";
var EXCLUDED_DIRS = new Array("Windows","PerfLogs","$Recycle.Bin","Boot","Recovery","System Volume Information","$Windows.~WS","$WINDOWS.~BT","$WINDOWS.~LS","$WinREAgent","Documents and Settings","ProgramData");
var CMD_OUTPUT_PATH = "";
var OUTPUT_PATH = "";
var SCRIPT_UNAME = WshShell.ExpandEnvironmentStrings("%USERNAME%");
var MACHINE_NAME = WshShell.ExpandEnvironmentStrings("%COMPUTERNAME%");
var OPREFIX = "***===," + MACHINE_NAME;
var ERRPREFIX = OPREFIX + ",script log,";
var FDATE = toChar(PDATE.getFullYear()) + toChar(PDATE.getMonth() + 1) + toChar(PDATE.getDate()) + toChar(PDATE.getHours()) + toChar(PDATE.getMinutes()) + toChar(PDATE.getSeconds());
var SILENT_MODE = 0;
var MASKING_MODE = 0;
var NETWORK_SCAN = 0;
var REMOVABLE_SCAN = 0;
var CUST_NAME = "palcust";
var PMASK = "PAL-MASKED";

checkScriptArgs(SCRIPT_ARGS);

CMD_OUTPUT_PATH = CMD_OUTPUT_PATH.replace(/^\s+|\s+$/gm,'');

OUTPUT_PATH = PCHOME;

if (CMD_OUTPUT_PATH.length > 0) {
    if (fso.FolderExists(CMD_OUTPUT_PATH)) {
        OUTPUT_PATH = CMD_OUTPUT_PATH;
    }
}

var SEARCH_DRV = getDriveList();
var ALL_DRV = getAllDrives();

if (SILENT_MODE < 1) {
    WScript.Echo("\n\n");
    WScript.Echo("Palisade Java Collection Tool v" + SCRIPT_VERSION + " - JScript");
    WScript.Echo("\nScan "+MACHINE_NAME+" for Java installations and processes...");
}

var SYS_JAVA_HOME = getJavaHome();

var FNAME = CUST_NAME + "-paljv-" + MACHINE_NAME + "__" + FDATE + "P" + PPID;

var PC_OUTPUT_FILE_fname = OUTPUT_PATH + "\\" + FNAME + ".txt";
var SYSINFO_TMP_FILE_fname = OUTPUT_PATH + "\\" + PPID + "-sysinfo.tmp";
var FILELIST_TMP_FILE_fname = OUTPUT_PATH + "\\" + PPID + "-detectedjava.tmp";
var ROOTDIRS_TMP_FILE_fname = OUTPUT_PATH + "\\" + PPID + "-rootdirs.tmp";
var JAVAVER_TMP_FILE_fname = OUTPUT_PATH + "\\" + PPID + "-javaversion.tmp";

writeOut(OPREFIX + "," + "script version" + "," + SCRIPT_NAME + "-" + SCRIPT_VERSION);
if (MASKING_MODE < 1) {
    writeOut(OPREFIX + "," + "script user" + "," + SCRIPT_UNAME);
} else {
    writeOut(OPREFIX + "," + "script user" + "," + PMASK);
}

testElevated();

writeOut(OPREFIX + "," + "script silent mode" + "," + SILENT_MODE);
writeOut(OPREFIX + "," + "script start time" + "," + FDATE);

runSysInfo();

try {
    var SYSINFO_TMP_FILE = fso.OpenTextFile(SYSINFO_TMP_FILE_fname, FRead, "True");

    while (!SYSINFO_TMP_FILE.AtEndOfStream) {
        SYSINFO_LINE = SYSINFO_TMP_FILE.ReadLine();
        INFO_TYPE = SYSINFO_LINE.substring(0, SYSINFO_LINE.indexOf(":"));
        INFO_STRING = SYSINFO_LINE.substring(SYSINFO_LINE.indexOf(":") + 1, SYSINFO_LINE.length).replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '');
        writeOut(OPREFIX + "," + INFO_TYPE + "," + INFO_STRING);
    }
    SYSINFO_TMP_FILE.Close();
    fso.DeleteFile(SYSINFO_TMP_FILE_fname);
} catch (err) {
    writeOut(ERRPREFIX + err.description);
}

writeOut(ALL_DRV);
writeOut(OPREFIX + "," + "java home" + "," + SYS_JAVA_HOME);

var driveList = SEARCH_DRV.split(",");
for (var ii = 0; ii < driveList.length; ii++) {
    drive = driveList[ii];
    var SCAN_DIRS = "";
    var drivecount = ii + 1;
    var lastChar = drive.charAt(drive.length - 1);

    if (lastChar != ("\\")) {
        drive = drive + "\\";
    }
    selectRootDirs();
    writeOut(OPREFIX + "," + "java collection in folders" + "," + drive + SCAN_DIRS);
    if (SILENT_MODE < 1) {
        WScript.StdOut.Write("\nThe following directories will be scanned on " + drive + " drive: " + SCAN_DIRS + "\n");
    }
    detectJavaPaths();
}

try {
    var FILELIST_TMP_FILE = fso.OpenTextFile(FILELIST_TMP_FILE_fname, FRead, "True");
    while (!FILELIST_TMP_FILE.AtEndOfStream) {
        FILELIST_LINE = FILELIST_TMP_FILE.ReadLine();
        TEST_PATH = FILELIST_LINE.substring(0, FILELIST_LINE.lastIndexOf("\\"));
        if (! (TEST_PATH.toLowerCase().match(/javapath/g)) && ! (TEST_PATH.toLowerCase().match(/systemx86/g))) {
            writeOut(OPREFIX + "," + "java jdk/jre detected folder" + "," + TEST_PATH);
            var JAVA_VERSION = getJavaVersion(TEST_PATH);
            writeOut(OPREFIX + "," + "java version" + "," + JAVA_VERSION);
            var JAVA_C_DATE = getJavaDate(TEST_PATH, "C");
            var JAVA_M_DATE = getJavaDate(TEST_PATH, "M");
            writeOut(OPREFIX + "," + "java date" + "," + JAVA_M_DATE + "<MDATE>" + JAVA_C_DATE + "<CDATE> " + TEST_PATH);
        }
    }
    FILELIST_TMP_FILE.Close();
    fso.DeleteFile(FILELIST_TMP_FILE_fname);
} catch (err) {
    writeOut(ERRPREFIX + err.description);
}

var PROCLIST = getProcessList();

if (PROCLIST!=="") {
    writeOut(PROCLIST);
}

if (SILENT_MODE < 1) {
    WScript.Echo("\n=====");
    WScript.Echo("= Please collect and send " + PC_OUTPUT_FILE_fname.substring(PC_OUTPUT_FILE_fname.lastIndexOf("\\") + 1, PC_OUTPUT_FILE_fname.length) + " file to Palisade Compliance for analysis.");
    WScript.Echo("=====\n");
}
var DATE_NOW = new Date();
var ENDDATE = toChar(DATE_NOW.getFullYear()) + toChar(DATE_NOW.getMonth() + 1) + toChar(DATE_NOW.getDate()) + toChar(DATE_NOW.getHours()) + toChar(DATE_NOW.getMinutes()) + toChar(DATE_NOW.getSeconds());

writeOut(OPREFIX + ",script end time," + ENDDATE);
writeOut("\<EOF\>");

/**
 * write message to err file
 */
function writeOut(outmsg) {
    var PC_OUTPUT_FILE = fso.OpenTextFile(PC_OUTPUT_FILE_fname, FAppend, "True");
    PC_OUTPUT_FILE.WriteLine(outmsg.toString());
    PC_OUTPUT_FILE.Close();
}

/**
 * collect System Info
 */
function runSysInfo() {
    runReturn = runCommand("systeminfo | findstr /B /C:\"OS Name\" /C:\"OS Version\" > \"" + SYSINFO_TMP_FILE_fname + "\"", 0);
    if (runReturn != 0) {
        writeOut(ERRPREFIX + "Command systeminfo returned with error code: " + runReturn);
    }
}

/**
 * test Elevated
 */
function testElevated() {
    runReturn = runCommand("net session", 0);
    if (runReturn != 0) {
        writeOut(OPREFIX + "," + "is elevated" + ",False");
    } else {
        writeOut(OPREFIX + "," + "is elevated" + ",True");
    }
}

/**
 * detect paths with java.exe
 */
function detectJavaPaths() {
    if (SCAN_DIRS === "") {
        if (SILENT_MODE < 1) {
            WScript.Echo("Search drive [" + drivecount + " of " + driveList.length + "], " + drive + " for java.exe ...");
        }

        var runReturn;
        runReturn = runCommand("\"cd /d \"" + drive + "\" && dir /a:-d /b /s " + "java.exe" + ">> \"" + FILELIST_TMP_FILE_fname + "\" && cd /d \"" + PCHOME + "\"\"", 0);

        if (runReturn != 0) {
            writeOut(ERRPREFIX + "Search of " + drive + " returned with error code: " + runReturn);
        }
    } else {
        var dirList = SCAN_DIRS.split("|");
        for (var dd = 0; dd < dirList.length; dd++) {
            cdir = dirList[dd];
            var dircount = dd + 1;
            var lastChar = cdir.charAt(cdir.length - 1);
            if (lastChar != ("\\")) {
                cdir = cdir + "\\";
            }

            if (SILENT_MODE < 1) {
                    WScript.Echo("Search drive [" + drivecount + " of " + driveList.length + "], directory [" + dircount + " of " + dirList.length + "], " + drive + cdir + " for java.exe ...");
            }

            var runReturn;
            runReturn = runCommand("\"cd /d \"" + drive + cdir + "\" && dir /a:-d /b /s " + "java.exe" + ">> \"" + FILELIST_TMP_FILE_fname + "\" && cd /d \"" + PCHOME + "\"\"", 0);

            if (runReturn != 0) {
                writeOut(ERRPREFIX + "Search of " + drive + cdir + " returned with error code: " + runReturn);
            }
        }
    }
}

/**
 * get the Java version for java path
 */
function getJavaVersion(THIS_PATH) {
    var runReturn;

    if (SILENT_MODE < 1) {
        WScript.Echo("Check Java version on\n"+THIS_PATH);
    }

    runReturn = runCommand("\"cd /d \"" + THIS_PATH + "\" && java -version 1" + ">> \"" + JAVAVER_TMP_FILE_fname + "\" 2>&1 && cd /d \"" + PCHOME + "\"\"", 0);

    if (runReturn != 0) {
        writeOut(ERRPREFIX + "java.exe from " + THIS_PATH + " returned with error code: " + runReturn);
    } else {
        try {
            var JAVAVER_TMP_FILE = fso.OpenTextFile(JAVAVER_TMP_FILE_fname, FRead, "True");
            var JAVA_VERSION = "";

            while (!JAVAVER_TMP_FILE.AtEndOfStream) {
                JAVAVER_LINE = JAVAVER_TMP_FILE.ReadLine();
                if (JAVA_VERSION === "") {
                    JAVA_VERSION = JAVAVER_LINE;
                } else {
                    JAVA_VERSION = JAVA_VERSION + " " + JAVAVER_LINE;
                }
            }
            JAVAVER_TMP_FILE.Close();
            fso.DeleteFile(JAVAVER_TMP_FILE_fname);
        } catch (err) {
            writeOut(ERRPREFIX + err.description);
        }
        return JAVA_VERSION;
    }
}

/**
 * get the Java installation date for java path
 */
function getJavaDate(THIS_PATH,DATE_TYPE) {
    try {
        var THIS_JAVA_BIN = fso.GetFile(THIS_PATH + "\\java.exe");
        var JAVA_DATE = "";
        if (DATE_TYPE === "C") {
            FILE_DATE = new Date(THIS_JAVA_BIN.DateCreated);
        } else {
            FILE_DATE = new Date(THIS_JAVA_BIN.DateLastModified);
        }
        FILE_YEAR = FILE_DATE.getFullYear();
        FILE_MONTH = toChar(Number(FILE_DATE.getMonth()) + 1);
        FILE_DAY = toChar(Number(FILE_DATE.getDate()));
        JAVA_DATE = FILE_YEAR + "-" + FILE_MONTH + "-" + FILE_DAY;
    } catch (err) {
        writeOut(ERRPREFIX + err.description);
    }
    return JAVA_DATE;
}

/**
 * convert one char month or day to two chars by adding 0 as suffix
 */
function toChar(xval) {
    if (xval < 10) {
        retstr = "0" + (xval).toString();
    } else {
        retstr = (xval).toString();
    }
    return retstr;
}

/**
 * detect keywords in space separated strings and mask the entire string that contains any of the keywords
 */
function stringMasking(str, palMask) {
    var splitInput = str.split(" ");
    var noOfSections = splitInput.length;
    var processedStr = "";

    for (var i = 0; i < noOfSections; i++) {
        if (splitInput[i].toLowerCase().indexOf('security') !== -1 || splitInput[i].toLowerCase().indexOf('pass') !== -1) {
            thisSection = palMask;
        } else {
            thisSection = splitInput[i]
        }
        if (processedStr.length > 0) {
            processedStr = (processedStr + " " + thisSection);
        } else {
            processedStr = thisSection;
        }
    }
    return processedStr;
}

/**
 * getProcessList - function to return the java process list and the initiator
 */
function getProcessList() {
    var procs = GetObject("WinMgmts:").InstancesOf("Win32_Process");
    var mainRes = "";
    procEnum = new Enumerator(procs);
    for (; !procEnum.atEnd(); procEnum.moveNext()) {
        var proc = procEnum.item();
        var cmd_line = proc.CommandLine;
        if (proc.Name && proc.Name.toLowerCase().match(/java*.exe/)) {
            if (mainRes) {
                mainRes += "\r\n"
            }
            if (cmd_line) {
                if (MASKING_MODE < 1) {
                    mainRes += OPREFIX + "," + "java process info" + "," + proc.Name + ": " + proc.ProcessID + ": " + cmd_line;
                } else {
                    cmd_line = stringMasking(cmd_line, PMASK);
                    mainRes += OPREFIX + "," + "java process info" + "," + proc.Name + ": " + proc.ProcessID + ": " + cmd_line;
                }
                mainRes += "\r\n" + OPREFIX + "," + "java command" + "," + proc.ExecutablePath;
            } else {
                mainRes += OPREFIX + "," + "java process error" + "," + "unable to retrieve info for java process " + proc.ProcessID;
            }
            if (proc.ExecutablePath) {
                var TEST_PATH = proc.ExecutablePath.substring(0, proc.ExecutablePath.lastIndexOf("\\"));
                var JAVA_VERSION = getJavaVersion(TEST_PATH);
                mainRes += "\r\n" + OPREFIX + "," + "java jdk/jre detected folder per process command" + "," + TEST_PATH;
                mainRes += "\r\n" + OPREFIX + "," + "java version per process command" + "," + JAVA_VERSION;
                var JAVA_C_DATE = getJavaDate(TEST_PATH,"C");
                var JAVA_M_DATE = getJavaDate(TEST_PATH,"M");
                mainRes += "\r\n" + OPREFIX + "," + "java date per process command" + "," + JAVA_M_DATE + "<MDATE>" + JAVA_C_DATE + "<CDATE> " + TEST_PATH;
            }
        }
    }
    return mainRes;
}

/**
 * get_pid - get the pid of the cscript running this.
 */
function get_pid() {
    var objWMIService = GetObject("winmgmts:\\\\.\\root\\CIMV2");
    var pidItems = objWMIService.ExecQuery("Select * from Win32_Process Where Name = 'cscript.exe'", "WQL",
        wbemFlagReturnImmediately | wbemFlagForwardOnly);
    var pid;
    try {
        var enumItems = new Enumerator(pidItems);
        for (; !enumItems.atEnd(); enumItems.moveNext()) {
            var objItem = enumItems.item();

            if (objItem.CommandLine.indexOf("collect_java.js") > -1)
                pid = objItem.ProcessID;
        }
    } catch (e) {
        pid = 0000;
        if (DEBUG)
            echo_debug("OBJItem error==" + e.description);
    }
    return pid;
}

/**
 * getJavaHome from Environment Variables
 */
function getJavaHome() {
    var objWMIService = GetObject("winmgmts:\\\\.\\root\\CIMV2");
    var colItems = objWMIService.ExecQuery("SELECT * FROM Win32_Environment", "WQL",
        wbemFlagReturnImmediately | wbemFlagForwardOnly);
    var enumItems = new Enumerator(colItems);
    var sysJavaHome = "not set";
    for (; !enumItems.atEnd(); enumItems.moveNext()) {
        var objItem = enumItems.item();
        if ((objItem.Name.indexOf("JAVA_HOME") > -1) && (objItem.UserName.indexOf("SYSTEM") > -1) && (sysJavaHome === "not set")) {
            var sysJavaHome = objItem.VariableValue;
        }
    }
    return (sysJavaHome);
}

/**
 * getDriveList - function to get all of the local/fixed drives on the system.
 */
function getDriveList() {
    var list, dEnum, driveItem;
    dEnum = new Enumerator(fso.Drives);
    list = "";
    for (; !dEnum.atEnd(); dEnum.moveNext()) {
        driveItem = dEnum.item();
        if ((driveItem.DriveType == 2) || ((driveItem.DriveType == 1) && (REMOVABLE_SCAN == 1)) || ((driveItem.DriveType == 3) && (NETWORK_SCAN == 1)))
            list = list + driveItem.Path + "\\,";
    }
    return (list.slice(0, -1));
}

/**
 * getAllDrives - function to retrieve list of mounted drives
 */
function getAllDrives() {
    var list, dEnum, driveItem;
    dEnum = new Enumerator(fso.Drives);
    mainRes = "";
    for (; !dEnum.atEnd(); dEnum.moveNext()) {
        driveItem = dEnum.item();
        if (driveItem.DriveLetter) {
            if (mainRes) {
                mainRes += "\r\n"
            }
            mainRes += OPREFIX + "," + "detected drive" + "," + driveItem.DriveLetter + "," + driveItem.DriveType + ",";
        }
    }
    return (mainRes);
}

/**
 * selectRootDirs - function to select Root Dirs to be scanned
 */
function selectRootDirs() {
    var runReturn;
    runReturn = runCommand("\"cd /d \"" + drive + "\" && dir /a:d /b > \"" + ROOTDIRS_TMP_FILE_fname + "\" && cd /d \"" + PCHOME + "\"\"", 0);

    if (runReturn != 0) {
        writeOut(ERRPREFIX + "Command to list root directories of " + drive + " returned with error code: " + runReturn);
    }

    try {
        var ROOTDIRS_TMP_FILE = fso.OpenTextFile(ROOTDIRS_TMP_FILE_fname, FRead, "True");
        while (!ROOTDIRS_TMP_FILE.AtEndOfStream) {
            var TO_BE_EXCLUDED=0;
            ROOTDIRS_LINE = ROOTDIRS_TMP_FILE.ReadLine();
            for (key in EXCLUDED_DIRS) {
                if (EXCLUDED_DIRS[key].toLowerCase() === ROOTDIRS_LINE.toLowerCase()) {
                    var TO_BE_EXCLUDED=1;
                }
            }
            if (TO_BE_EXCLUDED==0) {
                if (SCAN_DIRS === "") {
                    SCAN_DIRS = ROOTDIRS_LINE;
                } else {
                    SCAN_DIRS = SCAN_DIRS + "|" + ROOTDIRS_LINE;
                }
            }
        }
        ROOTDIRS_TMP_FILE.Close();
        fso.DeleteFile(ROOTDIRS_TMP_FILE_fname);
    } catch (err) {
        writeOut(ERRPREFIX + err.description);
    }
}

/**
 * runCommand - Runs a specific command, uses WindowStyle and waits for the
 *                command to return.
 */
function runCommand(theRunCommand, windowStyle) {
    var cmdLine = "cmd.exe /c " + theRunCommand;
    var errorCode;
    errorCode = WshShell.Run(cmdLine, windowStyle, true);
    return errorCode;
}

/**
 * check Script Arguments
 */
function checkScriptArgs(argVals) {
    for (var ii = 0; ii < argVals.length; ii++) {
        if (argVals.Item(ii).indexOf("-") == 0) {
            switch (argVals.Item(ii)) {
                case "-silent" :
                    SILENT_MODE = 1;
                    break;
                case "-restricted" :
                    MASKING_MODE = 1;
                    break;
                case "-includenetwork" :
                    NETWORK_SCAN = 1;
                    break;
                case "-includeremovable" :
                    REMOVABLE_SCAN = 1;
                    break;
                case "-output" :
                    CMD_OUTPUT_PATH = argVals.Item(ii+1);
                    break;
                default :
                    break;
            }
        }
    }
}